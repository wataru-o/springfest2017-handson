package com.example.springfest2017.handson.boothandson.ex4;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.springfest2017.handson.boothandson.person.Person;
import com.example.springfest2017.handson.boothandson.person.PersonService;

public class PersonInputController {

	private PersonService personService;

	public PersonInputController(PersonService personService) {
		this.personService = personService;
	}

	public String showForm() {
		return null;
	}

	public String onSubmit() {

		return "showPerson";
	}
}
