package com.example.springfest2017.handson.boothandson.person;

import java.util.List;

public interface PersonService {

	List<Person> findAll();

	Person findById(long id);

	void create(Person person);
}
