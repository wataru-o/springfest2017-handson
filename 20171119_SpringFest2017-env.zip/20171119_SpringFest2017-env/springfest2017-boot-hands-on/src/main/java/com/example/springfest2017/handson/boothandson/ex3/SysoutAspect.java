package com.example.springfest2017.handson.boothandson.ex3;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

public class SysoutAspect {

	// メソッド指定の例
	// execution(* com.example..*Service.*(..))
	public void before() {
		System.out.println("メソッド実行前に表示");
	}
}
