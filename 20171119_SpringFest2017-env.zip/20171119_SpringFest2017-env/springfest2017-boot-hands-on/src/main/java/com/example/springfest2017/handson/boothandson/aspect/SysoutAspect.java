package com.example.springfest2017.handson.boothandson.aspect;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

public class SysoutAspect {

	// メソッド指定の例
	// "execution(* com.example..*Service.*(..))")
	public void before() {
		System.out.println("メソッド実行前に表示");
	}

	// メソッド指定の例
	// "execution(* com.example..*Service.*(..))")
	public void after() {
		System.out.println("メソッド実行後に表示");
	}
}
