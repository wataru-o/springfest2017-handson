package com.example.springfest2017.handson.boothandson.person;

import java.util.LinkedList;
import java.util.List;

import org.springframework.stereotype.Service;

@Service
public class MockPersonServiceImpl implements PersonService {

	@Override
	public List<Person> findAll() {
		System.out.println("findAll execute");
		List<Person> list = new LinkedList<>();

		list.add(new Person(100, "太郎", "東京都"));
		list.add(new Person(200, "次郎", "神奈川県"));
		list.add(new Person(300, "三郎", "埼玉県"));

		return list;
	}

	@Override
	public Person findById(long id) {
		System.out.println("findById execute");
		return new Person(id, "太郎", "東京都");
	}

	@Override
	public void create(Person person) {
		System.out.println("create execute");
		System.out.println("Personを作成しました -> " + person);
	}
}
