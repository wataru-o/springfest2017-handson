package com.example.springfest2017.handson.boothandson.ex4;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.springfest2017.handson.boothandson.person.Person;
import com.example.springfest2017.handson.boothandson.person.PersonService;

@Controller
@RequestMapping("/ex4/person/input")
public class PersonInputController {

	private PersonService personService;

	public PersonInputController(PersonService personService) {
		this.personService = personService;
	}

	@GetMapping
	public String showForm() {
		return "inputPerson";
	}

	@PostMapping
	public String onSubmit(@ModelAttribute("p") Person person) {
		personService.create(person);

		return "showPerson";
	}
}
