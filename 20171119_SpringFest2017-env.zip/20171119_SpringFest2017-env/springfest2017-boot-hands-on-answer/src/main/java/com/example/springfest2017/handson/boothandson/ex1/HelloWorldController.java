package com.example.springfest2017.handson.boothandson.ex1;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class HelloWorldController {

	@GetMapping("/ex1/hello")
	public String showHello(@RequestParam String name, Model model ) {
		model.addAttribute("hello", "こんにちは、" + name + "さん！！");

		return "hello";
	}
}
