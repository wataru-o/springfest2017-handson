package com.example.springfest2017.handson.boothandson.ex2;

import java.util.LinkedList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.springfest2017.handson.boothandson.person.Person;

@Controller
@RequestMapping("/ex2")
public class PersonViewController {

	@GetMapping("/person/{id}")
	public String showPerson(@PathVariable long id, Model model) {
		Person person = new Person(id, "太郎", "東京都");
		model.addAttribute("p", person);

		return "showPerson";
	}

	@GetMapping("/person")
	public String showPersonList(Model model) {
		List<Person> list = new LinkedList<>();

		list.add(new Person(100, "太郎", "東京都"));
		list.add(new Person(200, "次郎", "神奈川県"));
		list.add(new Person(300, "三郎", "埼玉県"));

		model.addAttribute("pList", list);

		return "showPersonList";
	}
}
