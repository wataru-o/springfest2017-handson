package com.example.springfest2017.handson.boothandson.ex3;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.springfest2017.handson.boothandson.person.Person;
import com.example.springfest2017.handson.boothandson.person.PersonService;

@Controller
@RequestMapping("/ex3")
public class PersonViewUsingServiceController {

	private PersonService personService;

	public PersonViewUsingServiceController(PersonService personService) {
		this.personService = personService;
	}

	@GetMapping("/person/{id}")
	public String showPerson(@PathVariable long id, Model model) {
		Person person = personService.findById(id);
		model.addAttribute("p", person);

		return "showPerson";
	}

	@GetMapping("/person")
	public String showPersonList(Model model) {
		List<Person> list = personService.findAll();
		model.addAttribute("pList", list);

		return "showPersonList";
	}
}
